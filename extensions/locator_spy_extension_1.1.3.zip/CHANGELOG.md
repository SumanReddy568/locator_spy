## [1.1.3] - 2025-04-26
- new fix

## [1.1.3] - 2025-04-26
- master sync

## [1.1.2] - 2025-04-19
- zipper fix

## [1.1.1] - 2025-04-11
- hover click deactivation fix in old extesnion 1.1.0

## [1.1.0] - 2025-04-10
- new perfomace feature

## [1.0.9] - 2025-04-08
- zipper changes

## [1.0.9] - 2025-04-08
- new enhancement, adding best locator changes

## [1.0.9] - 2025-04-04
- new changes

## [1.1.0] - 2025-04-04
- zipper change

## [1.0.9] - 2025-04-04
- readme.d changes

## [1.0.8] - 2025-04-04
- zippeee new changes

## [1.0.9] - 2025-04-04
- zipper backlog ext change

## [1.0.9] - 2025-04-04
- zipper fix

## [1.0.9] - 2025-04-04
- pop up humburger fix, and service worker enhancements

## [1.0.8] - 2025-04-03
- final

## [1.0.9] - 2025-04-03
- del

## [1.0.8] - 2025-04-03
- version bump

## [1.0.8] - 2025-04-03
- final fix for 1.0.8

## [1.0.1] - 2025-04-03
- verion fix in pop up

## [1.0.8] - 2025-04-03
- Merge branch master of https://github.com/SumanReddy568/locator_spy

## [1.0.9] - 2025-04-03
- pop up changes sed change

## [1.0.8] - 2025-04-03
- pop up changes sed change

## [1.0.8] - 2025-04-03
- pop up changes

## [1.0.8] - 2025-04-03
- pop up changes

## [1.0.8] - 2025-04-03
- version bump

## [1.0.9] - 2025-04-03
- service worker fix

## [1.0.7] - 2025-03-30
- Merge pull request #7 from SumanReddy568/enhace_ziper Enhace ziper

## [1.0.8] - 2025-03-30
- Merge pull request #6 from SumanReddy568/enhace_ziper zipeer change

## [1.0.7] - 2025-03-29
- pannel headder update

## [1.0.6] - 2025-03-29
- Merge pull request #5 from SumanReddy568/loc_acc_imp improved xpath accuracy

## [1.0.5] - 2025-03-29
- Merge pull request #4 from SumanReddy568/dev2 acuracy improve

## [1.0.4] - 2025-03-29
- Merge pull request #2 from SumanReddy568/develop1 added change log file mainatence and fixed version update in pannel.html

# Changelog

All notable changes to this project will be documented in this file.

