function sendLifecycleEvent(eventName, data = {}) {
  // Recorder captures run the generator silently (see recGenerateLocatorsSafe).
  if (window.__locatorSpyQuiet) return;
  try {
    if (chrome.runtime?.id) {
      chrome.runtime.sendMessage({
        action: "locatorLifecycle",
        eventName,
        data: { ...data, url: window.location.href },
      });
    }
  } catch (e) {
    // Ignore
  }
}
window.sendLifecycleEvent = sendLifecycleEvent;

// Mirror the user-selected engine (chrome.storage.local.locatorEngine) into
// window.LocatorSpyConfig so the v2 dispatcher routes calls correctly. "v3"
// runs the v2 generator, then merges the API's results in; "v4" (default)
// shows only the API's results. Synchronous callers (recorder) get v2 for both.
function applyEngineConfig(engine) {
  const e = ["v1", "v2", "v3"].includes(engine) ? engine : "v4";
  window.LocatorSpyConfig = Object.assign({}, window.LocatorSpyConfig, { engine: e });
}
try {
  if (chrome.storage?.local) {
    chrome.storage.local.get("locatorEngine", (result) => {
      applyEngineConfig(result.locatorEngine || "v4");
    });
    chrome.storage.onChanged.addListener((changes, area) => {
      if (area === "local" && changes.locatorEngine) {
        applyEngineConfig(changes.locatorEngine.newValue);
      }
    });
  }
} catch (e) {
  // Ignore — fall back to dispatcher default (v2 generator, no enhancement).
}

if (window.seleniumLocatorHelperInjected) {
  // Already injected, skip
} else {
  window.seleniumLocatorHelperInjected = true;

  // Function to inject and wait for helper script
  async function injectHelperScript() {
    try {
      if (window.LocatorHelper) {
        return window.LocatorHelper;
      }

      // Inject the helper script
      const script = document.createElement("script");
      script.src = chrome.runtime.getURL("locator_helper.js");
      const loadPromise = new Promise((resolve, reject) => {
        script.onload = () => resolve();
        script.onerror = () =>
          reject(new Error("Failed to load helper script"));
      });
      document.head.appendChild(script);
      await loadPromise;

      // Wait for LocatorHelper to be available
      for (let i = 0; i < 50; i++) {
        // 5 second timeout
        if (window.LocatorHelper) {
          return window.LocatorHelper;
        }
        await new Promise((r) => setTimeout(r, 100));
      }
      throw new Error("LocatorHelper not found after injection");
    } catch (err) {
      console.error("[LocatorSpy] Failed to inject helper:", err);
      throw err;
    }
  }

  // Wait for both dependencies to be available
  async function waitForDependencies(maxWaitTime = 10000) {
    const start = Date.now();
    while (Date.now() - start < maxWaitTime) {
      if (
        typeof window.generateLocators === "function" &&
        window.LocatorHelper
      ) {
        return;
      }
      await new Promise((r) => setTimeout(r, 100));
    }
    throw new Error("Timed out waiting for dependencies");
  }

  // Initialize with proper dependency handling
  injectHelperScript()
    .then(() => waitForDependencies())
    .then(() => {
      initializeContentScript();
    })
    .catch((error) => {
      console.error("[LocatorSpy] Failed to initialize:", error.message);
    });

  function initializeContentScript() {
    // Main functionality wrapped in an IIFE to prevent global scope pollution
    (function () {
      // Suppress repeated error logs
      let extensionContextInvalidated = false;
      let locatorGeneratorMissing = false;

      if (typeof window.generateLocators !== "function") {
        if (!locatorGeneratorMissing) {
          console.error(
            "[LocatorSpy] generateLocators is not defined. Ensure locator_generator.js is loaded before content.js."
          );
          locatorGeneratorMissing = true;
        }
        return;
      }

      // Utility Classes
      class DOMDiffer {
        constructor() {
          this.previousDOM = null;
          this.mutations = [];
          this.observer = null;
          this.isTracking = false;
        }

        startTracking() {
          if (this.isTracking) return;

          this.previousDOM = document.documentElement.cloneNode(true);
          this.mutations = [];

          this.observer = new MutationObserver((mutations) => {
            this.mutations = this.mutations.concat(
              Array.from(mutations).map((m) => ({
                type: m.type,
                target: m.target.nodeName,
                addedNodes: m.addedNodes.length,
                removedNodes: m.removedNodes.length,
                timestamp: Date.now(),
              }))
            );
          });

          this.observer.observe(document.documentElement, {
            childList: true,
            attributes: true,
            characterData: true,
            subtree: true,
          });

          this.isTracking = true;
        }

        stopTracking() {
          if (!this.isTracking)
            return { added: [], removed: [], modified: [], mutations: [] };

          this.isTracking = false;
          if (this.observer) {
            this.observer.disconnect();
          }

          const changes = this.getDOMChanges();
          this.mutations = [];
          this.previousDOM = null;
          return changes;
        }

        getDOMChanges() {
          const changes = {
            added: [],
            removed: [],
            modified: [],
            mutations: this.mutations,
          };

          if (!this.previousDOM) return changes;

          const currentDOM = document.documentElement;
          this._compareNodes(this.previousDOM, currentDOM, changes);

          return changes;
        }

        _compareNodes(oldNode, newNode, changes) {
          if (!oldNode || !newNode) return;

          if (oldNode.nodeType === Node.ELEMENT_NODE) {
            const oldAttrs = Array.from(oldNode.attributes || []);
            const newAttrs = Array.from(newNode.attributes || []);

            if (oldAttrs.length !== newAttrs.length) {
              changes.modified.push({
                element: newNode,
                type: "attributes",
              });
            } else {
              for (let i = 0; i < oldAttrs.length; i++) {
                if (oldAttrs[i].value !== newAttrs[i].value) {
                  changes.modified.push({
                    element: newNode,
                    type: "attributes",
                  });
                  break;
                }
              }
            }
          }

          const oldChildren = Array.from(oldNode.childNodes);
          const newChildren = Array.from(newNode.childNodes);

          const maxLength = Math.max(oldChildren.length, newChildren.length);
          for (let i = 0; i < maxLength; i++) {
            const oldChild = oldChildren[i];
            const newChild = newChildren[i];

            if (!oldChild && newChild) {
              changes.added.push(newChild);
            } else if (oldChild && !newChild) {
              changes.removed.push(oldChild);
            } else if (
              oldChild.nodeType === Node.ELEMENT_NODE &&
              newChild.nodeType === Node.ELEMENT_NODE
            ) {
              this._compareNodes(oldChild, newChild, changes);
            }
          }
        }
      }

      class PerformanceTracker {
        constructor() {
          this.metrics = new Map();
          this.marks = new Set();
        }

        startMeasure(locatorType, locatorValue) {
          const key = `${locatorType}:${locatorValue}`;
          const markName = `start_${key}`;

          performance.mark(markName);
          this.marks.add(markName);

          this.metrics.set(key, {
            start: performance.now(),
            type: locatorType,
            value: locatorValue,
          });
        }

        endMeasure(locatorType, locatorValue) {
          const key = `${locatorType}:${locatorValue}`;
          const metric = this.metrics.get(key);
          const markName = `start_${key}`;

          if (metric && this.marks.has(markName)) {
            const measureName = `measure_${key}`;
            performance.measure(measureName, markName);

            const measure = performance.getEntriesByName(measureName).pop();
            metric.duration = measure.duration;

            // Cleanup
            performance.clearMarks(markName);
            performance.clearMeasures(measureName);
            this.marks.delete(markName);

            return metric;
          }
          return null;
        }

        getMetrics() {
          return Array.from(this.metrics.values()).filter(
            (metric) => metric.duration !== undefined
          );
        }

        clearMetrics() {
          this.metrics.clear();
          this.marks.forEach((mark) => {
            performance.clearMarks(mark);
          });
          this.marks.clear();
        }
      }

      class NetworkRequestMapper {
        constructor() {
          this.requests = new Map();
          this.observer = null;
          this.startTime = null;
          this.isTracking = false;
        }

        startTracking() {
          if (this.isTracking) return;

          this.startTime = performance.now();
          this.requests.clear();

          try {
            this.observer = new PerformanceObserver((list) => {
              const entries = list.getEntries();
              entries.forEach((entry) => {
                if (entry.entryType === "resource") {
                  this.requests.set(entry.name, {
                    url: entry.name,
                    startTime: entry.startTime,
                    duration: entry.duration,
                    type: entry.initiatorType,
                    size: entry.transferSize || 0,
                  });
                }
              });
            });

            this.observer.observe({ entryTypes: ["resource"] });
            this.isTracking = true;
          } catch (error) {
            // PerformanceObserver may be unsupported in some contexts
          }
        }

        stopTracking() {
          if (!this.isTracking) return [];

          this.isTracking = false;
          if (this.observer) {
            this.observer.disconnect();
          }

          const requests = Array.from(this.requests.values())
            .filter((req) => req.startTime >= this.startTime)
            .map((req) => ({
              ...req,
              duration: Math.round(req.duration),
              size: Math.round(req.size / 1024), // Convert to KB
            }));

          this.requests.clear();
          return requests;
        }
      }

      let isLocatorModeActive = false;
      let highlightedElement = null;
      let hoveredElement = null;
      let contextCheckInterval = null;
      let lastValidatedElement = null;
      // The element the panel is currently showing locators for. When a
      // locator matches several nodes, this is the one worth highlighting.
      let lastSelectedElement = null;

      // ── v4: API-only engine (default) ───────────────────────────────────
      // Per-element cache like v3 below, but hover waits for the pointer to
      // rest (V4_REST_MS) and never locks the highlight. The panel shows only
      // what /generate-locator returns — blank while waiting,
      // and on failure just the reason (`v4Failed`), never v2's results.
      let v4ClickFor = null; // element a click is waiting on (it sends the result)
      const v4Cache = new WeakMap(); // element -> { fp, result }
      const v4Pending = new WeakMap(); // element -> Promise<result>

      const v4Enabled = () =>
        (window.LocatorSpyConfig || {}).engine === "v4" &&
        typeof window.fetchLocatorsV4 === "function";

      function v4Cached(el) {
        const hit = v4Cache.get(el);
        return hit && hit.fp === v3Fingerprint(el) ? hit.result : null;
      }

      // Resolves to the API result, or { error }. Errors aren't cached.
      function v4Result(el) {
        const cached = v4Cached(el);
        if (cached) return Promise.resolve(cached);
        if (v4Pending.has(el)) return v4Pending.get(el);
        const fp = v3Fingerprint(el);
        const p = window.fetchLocatorsV4(el).then((r) => {
          v4Pending.delete(el);
          if (r && !r.error) v4Cache.set(el, { fp, result: r });
          return r && !r.error ? r : { error: (r && r.error) || "unknown" };
        });
        v4Pending.set(el, p);
        return p;
      }

      // ── v3 advanced analysis ────────────────────────────────────────────
      // Starts once the pointer rests on an element (V3_DWELL_MS), so moving
      // across the page doesn't fire an API + AI call per element. While one
      // runs, hovering other elements is ignored (the highlight stays on the
      // element being analysed) until it finishes. Results are cached per
      // element + outerHTML, so re-hovering or clicking it later is instant.
      const V3_DWELL_MS = 400;
      // v4 hover calls the API (a full AI run) only once the pointer has been
      // completely still this long — any mousemove restarts the wait — so
      // sweeping across a page doesn't fire a request per brief pause. A click
      // calls immediately. The highlight is never locked: hovering elsewhere
      // just leaves an in-flight result to land in v4Cache, unused.
      const V4_REST_MS = 2000;
      let v4RestEl = null; // hovered element waiting for the pointer to rest

      function armV4Rest() {
        clearTimeout(v3DwellTimer);
        const el = v4RestEl;
        v3DwellTimer = setTimeout(() => {
          v4RestEl = null;
          if (!isLocatorModeActive || hoveredElement !== el) return;
          v4Result(el).then((result) => {
            if (hoveredElement !== el || v4ClickFor === el) return; // moved on, or a click took over
            sendMessageToBackground(
              result.error
                ? { action: "v4Failed", error: result.error }
                : { action: "getLocators", locators: result, htmlContext: el.outerHTML, trigger: "hover" }
            );
          });
        }, V4_REST_MS);
      }
      const onPointerMove = () => { if (v4RestEl) armV4Rest(); };
      let v3Busy = null; // element whose analysis is in flight
      let v3DwellTimer = null;
      const v3Cache = new WeakMap(); // element -> { fp, result }

      const v3Enabled = () =>
        (window.LocatorSpyConfig || {}).engine === "v3" &&
        typeof window.enhanceLocatorsV3 === "function";
      // Our own highlight outline must not invalidate the cache, and neither
      // may interaction state the site toggles while you hover (Booking's nav
      // flips aria-expanded as its dropdown opens): that made the same element
      // look "changed" and re-request the server. Mirrors keyHtml() in the
      // worker (src/open-api/locator.js) — keep the two lists in sync.
      const STATE_ATTR_RE = /\s(?:aria-(?:expanded|selected|pressed|checked|hidden|busy)|data-state|data-headlessui-state|tabindex)="[^"]*"/gi;
      const STATE_CLASS_RE = /^(is-|has-)?(hover|hovered|active|focus|focused|focus-visible|open|opened|selected|expanded|show|showing|visible|current)$/i;
      const v3Fingerprint = (el) =>
        (el.outerHTML || "")
          .replace(/outline(-offset)?\s*:\s*[^;"]+;?/gi, "")
          .replace(STATE_ATTR_RE, "")
          .replace(/\sclass="([^"]*)"/g, (m, v) => ` class="${v.split(/\s+/).filter((c) => c && !STATE_CLASS_RE.test(c)).join(" ")}"`);

      function v3Cached(el) {
        const hit = v3Cache.get(el);
        return hit && hit.fp === v3Fingerprint(el) ? hit.result : null;
      }

      // Run (or reuse) the analysis for `el`; `base` is its v2 result. The
      // panel gets `v3Started`, then always a `locatorsEnhanced` (result or
      // error) — but only while `el` is still the element on screen.
      function runV3(el, base) {
        if (!v3Enabled() || !el || !base) return;
        sendMessageToBackground({ action: "v3Started" });
        const cached = v3Cached(el);
        if (cached) {
          sendMessageToBackground({ action: "locatorsEnhanced", locators: cached, htmlContext: el.outerHTML });
          return;
        }
        if (v3Busy === el) return; // already in flight; its result will be sent
        v3Busy = el;
        const fp = v3Fingerprint(el);
        window.enhanceLocatorsV3(el, base).then((enhanced) => {
          v3Busy = null;
          const ok = enhanced && !enhanced.error;
          if (ok) v3Cache.set(el, { fp, result: enhanced });
          if (el !== hoveredElement && el !== lastSelectedElement) return;
          sendMessageToBackground(
            ok
              ? { action: "locatorsEnhanced", locators: enhanced, htmlContext: el.outerHTML }
              : { action: "locatorsEnhanced", locators: null, error: (enhanced && enhanced.error) || "unknown" }
          );
        });
      }

      // Initialize utility instances
      const domDiffer = new DOMDiffer();
      const performanceTracker = new PerformanceTracker();
      const networkMapper = new NetworkRequestMapper();

      // Wrapper for sending messages with error handling
      function sendMessageToBackground(message, callback) {
        try {
          if (!chrome.runtime?.id) {
            if (!extensionContextInvalidated) {
              console.error("[LocatorSpy] Extension context invalidated - cannot send message");
              extensionContextInvalidated = true;
            }
            deactivateLocatorMode();
            return;
          }

          chrome.runtime.sendMessage(message, (response) => {
            if (chrome.runtime.lastError) {
              // Only a dead extension context (reload/update) is fatal. Other
              // errors are transient — e.g. "Receiving end does not exist" while
              // MV3 restarts the idle service worker. Deactivating on those
              // silently turned locator mode off in the page while the panel
              // still showed it Active, so hovering did nothing until a refresh.
              console.warn("[LocatorSpy] Message error:", chrome.runtime.lastError.message);
              if (!chrome.runtime?.id) deactivateLocatorMode();
              if (callback) callback(null, chrome.runtime.lastError);
              return;
            }
            if (callback) callback(response);
          });
        } catch (error) {
          if (!extensionContextInvalidated) {
            console.error("[LocatorSpy] sendMessageToBackground error:", error);
            extensionContextInvalidated = true;
          }
          deactivateLocatorMode();
          if (callback) callback(null, error);
        }
      }

      // Import generateLocators from locator_generator.js
      // (Assume locator_generator.js is loaded as a content script before this file)
      // If using modules, you could use: import { generateLocators } from './locator_generator.js';
      // For now, assume generateLocators is available globally.

      // Debounce function for smoother highlighting
      function debounce(func, wait) {
        let timeout;
        return function executedFunction(...args) {
          const later = () => {
            clearTimeout(timeout);
            func(...args);
          };
          clearTimeout(timeout);
          timeout = setTimeout(later, wait);
        };
      }

      // Highlight element with a border (delegates to LocatorHelper).
      function highlightElement(element) {
        highlightedElement = LocatorHelper.highlightElement(
          element,
          highlightedElement
        );
      }

      function removeHighlight() {
        if (highlightedElement) {
          LocatorHelper.removeHighlight(highlightedElement);
          highlightedElement = null;
        }
      }

      // Handle mouseover events in locator mode with debounce
      const debouncedMouseOver = debounce((event) => {
        if (!isLocatorModeActive) return;

        // Ignore if same element
        if (hoveredElement === event.target) return;
        // v3 analysis in flight: hold the current element until it ends.
        // (v4 doesn't lock — see V4_REST_MS.)
        if (v3Busy) return;

        event.stopPropagation();
        event.preventDefault();

        hoveredElement = event.target;
        highlightElement(hoveredElement);

        const el = hoveredElement;
        clearTimeout(v3DwellTimer);
        v4RestEl = null;

        if (v4Enabled()) {
          const done = v4Cached(el);
          if (done) {
            sendMessageToBackground({ action: "getLocators", locators: done, htmlContext: el.outerHTML, trigger: "hover" });
            return;
          }
          sendMessageToBackground({ action: "v4Pending", tagName: el.tagName.toLowerCase() });
          v4RestEl = el;
          armV4Rest();
          return;
        }

        const cached = v3Enabled() ? v3Cached(el) : null;
        const locators = cached || generateLocators(el);
        sendMessageToBackground({
          action: "getLocators",
          locators: locators,
          htmlContext: el.outerHTML,
          trigger: "hover",
        });

        if (!cached && v3Enabled()) {
          v3DwellTimer = setTimeout(() => {
            if (isLocatorModeActive && hoveredElement === el) runV3(el, locators);
          }, V3_DWELL_MS);
        }
      }, 50); // 50ms debounce

      // Handle click events in locator mode
      function handleClick(event) {
        if (!isLocatorModeActive) return;

        event.stopPropagation();
        event.preventDefault();

        // While a v3 analysis runs the highlight is pinned to its element, so a
        // click selects that element — what's highlighted is what you get.
        const clickedElement = v3Busy || event.target;
        lastSelectedElement = clickedElement;
        clearTimeout(v3DwellTimer);
        v4RestEl = null;

        const elementDetails = {
          tagName: clickedElement.tagName?.toLowerCase(),
          id: clickedElement.id || null,
          className: (clickedElement.className && String(clickedElement.className).slice(0, 100)) || null,
          name: clickedElement.getAttribute("name") || null,
          dataTestId: clickedElement.getAttribute("data-testid") || clickedElement.getAttribute("data-test-id") || null,
          ariaLabel: clickedElement.getAttribute("aria-label") || null,
          role: clickedElement.getAttribute("role") || null,
          outerHTMLPreview: (clickedElement.outerHTML || "").slice(0, 300),
        };
        sendLifecycleEvent("element_sent_to_generation", { element: elementDetails });

        // v4: wait for the API result (instant if already fetched on hover),
        // then hand it on exactly like a normal click result.
        if (v4Enabled()) {
          if (!v4Cached(clickedElement)) {
            sendMessageToBackground({ action: "v4Pending", tagName: clickedElement.tagName.toLowerCase() });
          }
          v4ClickFor = clickedElement;
          v4Result(clickedElement).then((result) => {
            if (v4ClickFor === clickedElement) v4ClickFor = null;
            if (lastSelectedElement !== clickedElement) return;
            if (result.error) {
              sendMessageToBackground({ action: "v4Failed", error: result.error });
              return;
            }
            sendMessageToBackground({ action: "saveLocator", locators: result, url: window.location.href, timestamp: new Date().toISOString() });
            sendMessageToBackground({ action: "getLocators", locators: result, metadata: result._metadata, htmlContext: clickedElement.outerHTML, trigger: "click" });
            sendLifecycleEvent("element_selected", { tagName: result.tagName, generatedLocators: result });
          });
          finishSelection();
          return;
        }

        // Already analysed on hover → show the full v3 result straight away.
        const v3Result = v3Enabled() ? v3Cached(clickedElement) : null;
        const locators = v3Result || generateLocators(clickedElement);

        // Save locator info and deactivate mode
        sendMessageToBackground({
          action: "saveLocator",
          locators: locators,
          url: window.location.href,
          timestamp: new Date().toISOString(),
        });

        // Include metrics in the message to DevTools
        sendMessageToBackground({
          action: "getLocators",
          locators: locators,
          metadata: locators._metadata,
          htmlContext: clickedElement.outerHTML,
          trigger: "click",
        });

        sendLifecycleEvent("element_selected", {
          tagName: locators.tagName,
          generatedLocators: locators,
        });

        // v3: not analysed yet (or still running) → start / re-announce it; the
        // merged result replaces the v2 list when it lands.
        if (!v3Result) runV3(clickedElement, locators);

        finishSelection();
      }

      // Deactivate locator mode after a selection, keeping the highlight
      // briefly so the user can still see the selection in the page.
      function finishSelection() {
        isLocatorModeActive = false;
        document.removeEventListener("mouseover", debouncedMouseOver, true);
        document.removeEventListener("mousemove", onPointerMove, true);
        document.body.style.cursor = "";

        sendMessageToBackground({ action: "locatorSelected" });

        setTimeout(() => {
          removeHighlight();
          if (contextCheckInterval) {
            clearInterval(contextCheckInterval);
            contextCheckInterval = null;
          }
          sendLifecycleEvent("mode_deactivated", { trigger: "auto_cleanup" });
          sendMessageToBackground({ action: "locatorModeDeactivated" });
        }, 10000);
      }

      // Ensure DOMDiffer starts tracking properly
      function initializeDomDiffer() {
        try {
          domDiffer.startTracking();
        } catch (error) {
          // Ignore
        }
      }

      function initializeNetworkMapper() {
        try {
          networkMapper.startTracking();
        } catch (error) {
          // Ignore
        }
      }

      function captureDomAndNetworkChanges() {
        try {
          const domChanges = domDiffer.stopTracking();
          const networkRequests = networkMapper.stopTracking();
          sendMessageToBackground({
            action: "captureMetrics",
            domChanges,
            networkRequests,
          });
        } catch (error) {
          // Ignore
        }
      }

      // Activate locator mode
      function activateLocatorMode() {
        if (isLocatorModeActive) return;

        sendLifecycleEvent("mode_activated", { message: "select element" });
        isLocatorModeActive = true;

        initializeDomDiffer();
        initializeNetworkMapper();

        document.addEventListener("mouseover", debouncedMouseOver, {
          capture: true,
          passive: false,
        });
        document.addEventListener("mousemove", onPointerMove, { capture: true, passive: true });
        document.addEventListener("click", handleClick, true);
        document.body.style.cursor = "crosshair";

        // Start context validity checks
        if (!contextCheckInterval) {
          contextCheckInterval = setInterval(checkContextValidity, 5000);
        }
      }

      // Deactivate locator mode
      function deactivateLocatorMode() {
        if (!isLocatorModeActive) return;

        sendLifecycleEvent("mode_deactivated", {});
        isLocatorModeActive = false;

        captureDomAndNetworkChanges();

        document.removeEventListener("mouseover", debouncedMouseOver, true);
        document.removeEventListener("mousemove", onPointerMove, true);
        document.removeEventListener("click", handleClick, true);
        document.body.style.cursor = "";
        clearTimeout(v3DwellTimer);
        v4RestEl = null;

        removeHighlight();
        hoveredElement = null;

        // Clear any remaining validation highlights
        if (lastValidatedElement) {
          lastValidatedElement.style.outline = "";
          lastValidatedElement.style.outlineOffset = "";
          lastValidatedElement.style.boxShadow = "";
          lastValidatedElement = null;
        }

        if (contextCheckInterval) {
          clearInterval(contextCheckInterval);
          contextCheckInterval = null;
        }

        sendMessageToBackground({
          action: "locatorModeDeactivated",
        });
      }

      // Check if extension context is still valid
      function checkContextValidity() {
        try {
          if (!chrome.runtime?.id) {
            if (!extensionContextInvalidated) {
              // Extension context invalidated - stopping retries
              extensionContextInvalidated = true;
            }
            deactivateLocatorMode(); // Stop locator mode if context is invalid
            return;
          }

          // Wake the service worker; a failed ping is transient (worker
          // restarting) unless the context itself is gone, which
          // sendMessageToBackground already handles.
          sendMessageToBackground({ action: "ping" });
        } catch (error) {
          if (!extensionContextInvalidated) {
            console.error("[LocatorSpy] Context check error:", error);
            extensionContextInvalidated = true;
          }
          deactivateLocatorMode();
        }
      }

      // Message listener with error handling
      function setupMessageListener() {
        try {
          chrome.runtime.onMessage.addListener(function (
            request,
            sender,
            sendResponse
          ) {
            if (!chrome.runtime?.id) {
              console.error("[LocatorSpy] Extension context invalidated in listener");
              deactivateLocatorMode();
              return;
            }

            // Recorder replay: background sends one step at a time (top frame).
            if (request.action === "runRecordedStep") {
              runRecordedStep(request.step).then(sendResponse);
              return true; // async response
            }

            if (request.action === "activateLocatorMode") {
              if (request.isActive) {
                activateLocatorMode();
              } else {
                deactivateLocatorMode();
              }
            }

            if (request.action === "validateLocator") {
              validateAndHighlightElement(
                request.locatorType,
                request.locatorValue,
                {
                  strategy: request.locatorStrategy || null,
                  verifyExpr: request.locatorVerifyExpr || null,
                  verifyKind: request.locatorVerifyKind || null,
                }
              );
            }

            // Reply synchronously. This used to `return true` (promising an
            // async reply) without ever calling sendResponse, so background's
            // `await chrome.tabs.sendMessage(...)` rejected on every locator-mode
            // toggle with "message channel closed before a response".
            sendResponse({ status: "ok" });
          });
        } catch (error) {
          console.error("[LocatorSpy] Failed to setup message listener:", error);
        }
      }

      // Run a locator against the document and return every node it matches.
      // `strategy` is the locator kind the panel sent along with the value, so
      // raw Selenium values (`username` for By.name) and framework locators
      // (`page.getByRole(...)`, resolved through `verifyExpr`) both work here
      // without inferring anything from the label.
      function queryAllForLocator(strategy, value, verifyExpr, verifyKind) {
        const run = (kind, expr) => {
          if (!expr) return [];
          try {
            if (kind === "xpath") {
              const r = document.evaluate(
                expr, document, null, XPathResult.ORDERED_NODE_SNAPSHOT_TYPE, null
              );
              const out = [];
              for (let i = 0; i < r.snapshotLength; i++) out.push(r.snapshotItem(i));
              return out;
            }
            return Array.from(document.querySelectorAll(expr));
          } catch (e) {
            return [];
          }
        };
        const normText = (s) => String(s || "").replace(/\s+/g, " ").trim();

        switch (strategy) {
          case "xpath":
            return run("xpath", value);
          case "css":
            return run("css", value);
          case "id": {
            const el = document.getElementById(value);
            return el ? [el] : [];
          }
          case "name":
            return Array.from(document.getElementsByName(value));
          case "class name":
            return Array.from(document.getElementsByClassName(value));
          case "tag name":
            return Array.from(document.getElementsByTagName(value));
          case "link text":
            return Array.from(document.getElementsByTagName("a")).filter(
              (a) => normText(a.textContent) === normText(value)
            );
          case "partial link text":
            return Array.from(document.getElementsByTagName("a")).filter((a) =>
              normText(a.textContent).includes(normText(value))
            );
          default:
            // Playwright spellings and anything else we don't parse: fall back
            // to the CSS/XPath equivalent the engine recorded for this locator.
            return run(verifyKind === "xpath" ? "xpath" : "css", verifyExpr);
        }
      }

      // ── Recorder replay ────────────────────────────────────────────────
      // Runs one recorded step. The element is found through the locators the
      // recorder captured (each carries the CSS/XPath the engine verified it
      // with): the first that matches exactly one element wins; failing that,
      // the recorded match position. Waits for it to appear (SPAs render late).
      const REPLAY_WAIT_MS = 6000;

      function findStepElement(step) {
        const list = step.locators && Array.isArray(step.locators.locators) ? step.locators.locators : [];
        let fallback = null;
        for (const l of list) {
          const nodes = queryAllForLocator(undefined, l.value, l.verifyExpr, l.verifyKind);
          if (nodes.length === 1) return nodes[0];
          if (!fallback && nodes.length > 1 && l.position && nodes[l.position - 1]) fallback = nodes[l.position - 1];
        }
        return fallback;
      }

      async function waitForStepElement(step) {
        const until = Date.now() + REPLAY_WAIT_MS;
        for (;;) {
          const el = findStepElement(step);
          if (el || Date.now() > until) return el;
          await new Promise((res) => setTimeout(res, 200));
        }
      }

      // Set a value the way a user would, so framework-controlled inputs
      // (React, Vue) see it: native setter + input/change events.
      function setNativeValue(el, value) {
        const proto = el instanceof HTMLTextAreaElement ? HTMLTextAreaElement.prototype
          : el instanceof HTMLSelectElement ? HTMLSelectElement.prototype : HTMLInputElement.prototype;
        const setter = Object.getOwnPropertyDescriptor(proto, "value")?.set;
        if (setter) setter.call(el, value); else el.value = value;
        el.dispatchEvent(new Event("input", { bubbles: true }));
        el.dispatchEvent(new Event("change", { bubbles: true }));
      }

      function flashReplay(el) {
        const prev = [el.style.outline, el.style.outlineOffset];
        el.style.outline = "2px solid #dc2626";
        el.style.outlineOffset = "2px";
        setTimeout(() => { el.style.outline = prev[0]; el.style.outlineOffset = prev[1]; }, 700);
      }

      async function runRecordedStep(step) {
        try {
          // Locator mode's capture-phase click handler would swallow replayed clicks.
          if (isLocatorModeActive) deactivateLocatorMode();
          if (step.action === "scroll") {
            window.scrollTo(step.x || 0, step.y || 0);
            return { ok: true };
          }
          if (step.action === "input" && step.isPassword) {
            return { ok: true, skipped: true, error: "password isn't stored by the recorder: type it yourself" };
          }
          const el = await waitForStepElement(step);
          if (!el) return { ok: false, error: "element not found on the page" };
          el.scrollIntoView({ block: "center", inline: "nearest" });
          flashReplay(el);
          if (step.action === "click") {
            el.click();
          } else if (step.action === "input" || step.action === "select") {
            if (typeof el.focus === "function") el.focus();
            setNativeValue(el, step.value == null ? "" : String(step.value));
          } else {
            return { ok: false, error: `can't replay "${step.action}" steps` };
          }
          return { ok: true };
        } catch (e) {
          return { ok: false, error: String((e && e.message) || e).slice(0, 160) };
        }
      }

      // Add validation handling
      function validateAndHighlightElement(type, value, opts) {
        opts = opts || {};
        // Clear previous validation highlight if exists
        if (lastValidatedElement) {
          lastValidatedElement.style.outline = "";
          lastValidatedElement.style.outlineOffset = "";
          lastValidatedElement.style.boxShadow = "";
          lastValidatedElement = null;
        }

        let element = null;
        let extraInfo = null;
        const lowerType = type.toLowerCase();

        // Preferred path: the panel told us exactly how to resolve this one.
        if (opts.strategy || opts.verifyExpr) {
          const found = queryAllForLocator(
            opts.strategy, value, opts.verifyExpr, opts.verifyKind
          );
          // Among several matches, highlight the element the panel is showing
          // locators for rather than whichever comes first in the document.
          element =
            (lastSelectedElement && found.includes(lastSelectedElement) && lastSelectedElement) ||
            (hoveredElement && found.includes(hoveredElement) && hoveredElement) ||
            found[0] ||
            null;
          if (found.length > 1) {
            extraInfo = `Matches ${found.length} elements. Highlighting #${
              found.indexOf(element) + 1
            }.`;
          }
          highlightValidationResult(element, type, value, extraInfo);
          return;
        }

        try {
          // 1. XPath Strategies
          if (
            lowerType.includes("xpath") ||
            value.startsWith("/") ||
            value.startsWith("(")
          ) {
            try {
              const result = document.evaluate(
                value,
                document,
                null,
                XPathResult.FIRST_ORDERED_NODE_TYPE,
                null
              );
              element = result.singleNodeValue;
            } catch (e) {
              // Invalid XPath - element remains null
            }
          }
          // 2. ID Strategy
          else if (lowerType === "id") {
            element = document.getElementById(value);
          }
          // 3. CSS Strategies (Explicit or detected)
          else if (
            lowerType.includes("css") ||
            lowerType.includes("selector")
          ) {
            try {
              element = document.querySelector(value);
            } catch (e) {
              // Invalid CSS selector
            }
          }
          // 4. Specific Strategies
          else if (lowerType === "class name") {
            element = document.getElementsByClassName(value)[0];
          } else if (lowerType === "tag name") {
            const elements = Array.from(document.getElementsByTagName(value));
            element = elements[0];
            // ... logic for index if multiple ...
            if (
              elements.length > 1 &&
              hoveredElement &&
              elements.includes(hoveredElement)
            ) {
              element = hoveredElement;
            }
          } else if (lowerType === "link text") {
            // ... existing link text logic ...
            const exactLinks = Array.from(
              document.getElementsByTagName("a")
            ).filter((link) => link.textContent.trim() === value);
            element = exactLinks[0];
            if (exactLinks.length > 1) {
              if (hoveredElement && exactLinks.includes(hoveredElement)) {
                element = hoveredElement;
              }
              chrome.runtime.sendMessage({
                action: "validationResult",
                success: true,
                locatorType: type,
                locatorValue: value,
                additionalInfo: `Found ${
                  exactLinks.length
                } matches. Using index ${exactLinks.indexOf(element) + 1}.`,
              });
            }
          } else if (lowerType === "partial link text") {
            // ... existing partial link text logic ...
            const partialLinks = Array.from(
              document.getElementsByTagName("a")
            ).filter((link) => link.textContent.includes(value));
            element = partialLinks[0];
            if (partialLinks.length > 1) {
              if (hoveredElement && partialLinks.includes(hoveredElement)) {
                element = hoveredElement;
              }
              chrome.runtime.sendMessage({
                action: "validationResult",
                success: true,
                locatorType: type,
                locatorValue: value,
                additionalInfo: `Found ${
                  partialLinks.length
                } matches. Using index ${partialLinks.indexOf(element) + 1}.`,
              });
            }
          }
          // 5. Default / Attribute Fallback
          else {
            // Try as a direct CSS selector first (e.g. if the user provided customized keys or AI output)
            try {
              element = document.querySelector(value);
            } catch (e) {
              // Not a valid selector, treat as Attribute selector (e.g. key="name", value="submit")
              try {
                const selector = `[${lowerType}="${value}"]`;
                element = document.querySelector(selector);
              } catch (e2) {
                // Not a valid attribute selector
              }
            }
          }

          highlightValidationResult(element, type, value, null);
        } catch (error) {
          chrome.runtime.sendMessage({
            action: "validationResult",
            success: false,
            locatorType: type,
            locatorValue: value,
          });
        }
      }

      // Flash the resolved element and report the outcome back to the panel.
      function highlightValidationResult(element, type, value, additionalInfo) {
        if (!element) {
          chrome.runtime.sendMessage({
            action: "validationResult",
            success: false,
            locatorType: type,
            locatorValue: value,
          });
          return;
        }

        // Store reference to currently highlighted element
        lastValidatedElement = element;

        // Add validation highlight effect
        element.style.transition = "all 0.3s ease";
        element.style.outline = "2px solid #4CAF50";
        element.style.outlineOffset = "2px";
        element.style.boxShadow = "0 0 10px rgba(76, 175, 80, 0.5)";

        chrome.runtime.sendMessage({
          action: "validationResult",
          success: true,
          locatorType: type,
          locatorValue: value,
          additionalInfo: additionalInfo || undefined,
        });

        // Remove highlight after 2 seconds
        setTimeout(() => {
          if (lastValidatedElement === element) {
            element.style.outline = "";
            element.style.outlineOffset = "";
            element.style.boxShadow = "";
            lastValidatedElement = null;
          }
        }, 2000);
      }

      // -------- Recorder mode --------
      // Independent of locator mode. While `recorderActive` is true in
      // chrome.storage.local, every interaction (clicks, typing into text
      // fields, select changes, scroll) is observed in the capture phase
      // (no preventDefault — the page still navigates / submits / etc.)
      // and forwarded to the background, which appends to
      // `recorderInteractions`. The Recorder view in the panel reads that
      // list and re-renders live.
      let isRecordingActive = false;

      function recIdNew() {
        return Date.now() + ":" + Math.random().toString(36).slice(2, 8);
      }

      function recSend(interaction) {
        try {
          chrome.runtime.sendMessage({
            action: "recorderAppend",
            interaction: interaction,
          });
        } catch (e) { /* extension context invalidated; user will reload */ }
      }

      function recGenerateLocatorsSafe(el) {
        try {
          if (typeof window.generateLocators === "function") {
            // Recording captures locators for the generated test, not a
            // generation the user asked for — so no lifecycle logs / analytics
            // events (every recorded click used to write 3 log rows).
            window.__locatorSpyQuiet = true;
            let locators;
            try { locators = window.generateLocators(el); } finally { window.__locatorSpyQuiet = false; }
            if (!locators || !Array.isArray(locators.locators)) return locators;
            // A recording holds one of these per step and lives in
            // chrome.storage, so keep only the handful of locators the code
            // generators and the AI prompt actually choose between.
            return Object.assign({}, locators, {
              locators: locators.locators.filter((l) => l.unique).slice(0, 8),
            });
          }
        } catch (e) { /* ignore */ }
        return null;
      }

      // Text inputs, textareas: capture *value* via the `change` event (fires
      // on blur), not via `click`, so we don't end up with a noisy click step
      // followed by an input step for the same field. Checkboxes / radios /
      // file inputs / buttons are still treated as clicks since their
      // change/click semantics line up with `.click()` in test code.
      function recIsTextInput(target) {
        if (!target || target.nodeType !== 1) return false;
        const tag = target.tagName ? target.tagName.toLowerCase() : "";
        if (tag === "textarea") return true;
        if (tag !== "input") return false;
        const type = (target.getAttribute("type") || "text").toLowerCase();
        return /^(text|email|password|search|tel|url|number|date|datetime-local|month|time|week)$/.test(type);
      }

      function recorderClickHandler(event) {
        if (!isRecordingActive) return;
        if (event.button !== 0) return; // primary button only
        const target = event.target;
        if (!target || target.nodeType !== 1) return;
        // Suppress clicks on text inputs / textareas — recorderInputHandler
        // will record the typed value when the user blurs the field.
        if (recIsTextInput(target)) return;

        const locators = recGenerateLocatorsSafe(target);
        if (!locators) return;

        recSend({
          id: recIdNew(),
          ts: Date.now(),
          action: "click",
          url: window.location.href,
          locators: locators,
          element: {
            tag: target.tagName ? target.tagName.toLowerCase() : null,
            text: ((target.innerText || target.textContent || "").trim() || "").slice(0, 80),
            role: target.getAttribute("role") || null,
          },
        });
      }

      function recorderChangeHandler(event) {
        if (!isRecordingActive) return;
        const target = event.target;
        if (!target || target.nodeType !== 1) return;
        const tag = target.tagName ? target.tagName.toLowerCase() : "";
        const type = (target.getAttribute("type") || "").toLowerCase();

        // Drop interactions whose semantics are already covered by the click
        // handler (checkbox / radio / button / submit / reset / file).
        if (tag === "input" && /^(checkbox|radio|button|submit|reset|file|hidden)$/.test(type)) return;
        if (tag !== "input" && tag !== "textarea" && tag !== "select") return;

        const locators = recGenerateLocatorsSafe(target);
        if (!locators) return;

        const isPassword = tag === "input" && type === "password";
        const rawValue = target.value == null ? "" : String(target.value);
        // Don't ship password values through chrome.storage.local — redact
        // at the source. Tests will need a real password injected by the
        // user; this gives them a placeholder to find-and-replace.
        const value = isPassword ? "<REDACTED_PASSWORD>" : rawValue;

        recSend({
          id: recIdNew(),
          ts: Date.now(),
          action: tag === "select" ? "select" : "input",
          value: value,
          isPassword: isPassword,
          url: window.location.href,
          locators: locators,
          element: {
            tag: tag,
            type: type || null,
            name: target.getAttribute("name") || null,
            text: (target.getAttribute("placeholder") || target.getAttribute("name") || "").slice(0, 80),
          },
        });
      }

      // Scroll capture: debounced so we emit a single step per "scroll
      // session" rather than one per scroll event. Window-level only — the
      // user's scroll position is what the test needs to reproduce visibility,
      // not which container scrolled.
      let recScrollTimer = null;
      function recorderScrollHandler() {
        if (!isRecordingActive) return;
        if (recScrollTimer) clearTimeout(recScrollTimer);
        recScrollTimer = setTimeout(() => {
          recScrollTimer = null;
          recSend({
            id: recIdNew(),
            ts: Date.now(),
            action: "scroll",
            x: Math.round(window.scrollX || 0),
            y: Math.round(window.scrollY || 0),
            url: window.location.href,
          });
        }, 350);
      }

      // Always-on listeners; cheap when recording is off (each guards on
      // isRecordingActive). Capture phase for click so we see it before the
      // page handles it; bubble for change (it's what change supports);
      // passive scroll so we never interfere with the page.
      document.addEventListener("click", recorderClickHandler, true);
      document.addEventListener("change", recorderChangeHandler, true);
      window.addEventListener("scroll", recorderScrollHandler, { passive: true });

      try {
        chrome.storage.local.get("recorderActive", (r) => {
          isRecordingActive = !!(r && r.recorderActive);
        });
        chrome.storage.onChanged.addListener((changes, area) => {
          if (area === "local" && changes.recorderActive) {
            isRecordingActive = !!changes.recorderActive.newValue;
          }
        });
      } catch (e) { /* ignore */ }

      // Initialize the content script
      function initialize() {
        try {
          setupMessageListener();
          checkContextValidity();

          sendMessageToBackground({
            action: "contentScriptReady",
            url: window.location.href,
            iconUrl: chrome.runtime.getURL("popup/icons/icon48.png"),
          });
        } catch (error) {
          console.error("[LocatorSpy] Content script initialization failed:", error);
        }
      }

      // Start the content script
      initialize();
    })();
  }
}
