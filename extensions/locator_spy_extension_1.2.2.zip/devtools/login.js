document.addEventListener('DOMContentLoaded', () => {
    initLogin();
});
