// Classic script (loaded without type="module"), so the shared
// utils/endpoints.js can't be imported here — keep the URL inline.
const WORKER_BASE = "https://open-api-worker.sumanreddy568.workers.dev";

// Compact human-readable counts: 1234 -> "1.2k", 2_500_000 -> "2.5M".
function formatStatCount(n) {
  if (n >= 1e6) return (n / 1e6).toFixed(n % 1e6 === 0 ? 0 : 1) + "M";
  if (n >= 1e3) return (n / 1e3).toFixed(n % 1e3 === 0 ? 0 : 1) + "k";
  return String(n);
}

// Fetch usage counters and paint them into #headerStats. Bearer-gated, so it
// only renders for logged-in users; stays hidden (no .has-data) when there's
// no token or on any failure, keeping the header clean.
async function renderHeaderStats() {
  const el = document.getElementById("headerStats");
  if (!el) return;
  try {
    const authToken = await new Promise((resolve) => {
      try {
        chrome.storage.local.get(["auth_token"], (r) => resolve(r && r.auth_token));
      } catch (e) {
        resolve(localStorage.getItem("auth_token"));
      }
    });
    if (!authToken) return;
    const res = await fetch(
      `${WORKER_BASE}/api/public-stats?product=locator_spy&source=locator-spy`,
      { method: "GET", headers: { Authorization: `Bearer ${authToken}` } }
    );
    if (!res.ok) return;
    const data = await res.json();
    if (!data || typeof data !== "object") return;

    const items = [
      { value: Number(data.users) || 0, label: "Users" },
      { value: Number(data.locators) || 0, label: "Locators" },
      { value: Number(data.aiOptimizations) || 0, label: "AI Runs" },
      { value: Number(data.countries) || 0, label: "Countries" },
    ];

    el.replaceChildren();
    const caption = document.createElement("span");
    caption.className = "stats-caption";
    caption.textContent = "Community stats";
    el.appendChild(caption);
    items.forEach((it) => {
      const stat = document.createElement("div");
      stat.className = "stat";
      stat.title = `${it.value.toLocaleString()} ${it.label.toLowerCase()}`;
      const value = document.createElement("span");
      value.className = "stat-value";
      value.textContent = formatStatCount(it.value);
      const label = document.createElement("span");
      label.className = "stat-label";
      label.textContent = it.label;
      stat.append(value, label);
      el.appendChild(stat);
    });
    el.classList.add("has-data");
  } catch (err) {
    console.warn("[LocatorSpy] Failed to fetch public stats:", err);
  }
}

document.addEventListener("DOMContentLoaded", function () {
  const locatorModeBtn = document.getElementById("locatorModeBtn");
  const locatorResults = document.getElementById("locatorResults");
  const savedLocators = document.getElementById("savedLocators");
  const themeToggleBtn = document.getElementById("themeToggleBtn");
  const copyNotification = document.getElementById("copyNotification");

  let isLocatorModeActive = false;

  // Community usage strip in the header. Fetched once on open; fails silently.
  renderHeaderStats();

  // Initialize theme from local storage
  if (localStorage.getItem("theme") === "dark") {
    document.body.classList.add("dark-mode");
    document.body.classList.remove("light-mode");
  } else {
    document.body.classList.add("light-mode");
    document.body.classList.remove("dark-mode");
  }

  // Initialize Feedback Service
  if (window.FeedbackService) {
    FeedbackService.setupFeedbackHandlers();
    FeedbackService.checkFeedbackStatus();
  }

  // Toggle locator mode with animation
  locatorModeBtn.addEventListener("click", async function () {
    // Check if user is gated by feedback
    if (window.FeedbackService) {
      const needsFeedback = await FeedbackService.checkIfNeedsFeedback();
      if (needsFeedback) {
        FeedbackService.selectedRating = "positive";
        const feedbackPrompt = document.getElementById("feedbackPrompt");
        if (feedbackPrompt) feedbackPrompt.textContent = "Please share your feedback to continue generating locators.";
        const feedbackModal = document.getElementById("feedbackModal");
        if (feedbackModal) feedbackModal.style.display = "block";
        return;
      }
    }
    isLocatorModeActive = !isLocatorModeActive;

    if (isLocatorModeActive) {
      locatorModeBtn.classList.add("active-mode");
      locatorModeBtn.classList.remove("pulse-animation");
      locatorModeBtn.innerHTML = `
        <svg class="icon" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
          <path d="M3 3l7.07 16.97 2.51-7.39 7.39-2.51L3 3z"></path>
        </svg>
        Locator Mode (Active)
      `;
    } else {
      locatorModeBtn.classList.remove("active-mode");
      locatorModeBtn.innerHTML = `
        <svg class="icon" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
          <path d="M3 3l7.07 16.97 2.51-7.39 7.39-2.51L3 3z"></path>
        </svg>
        Locator Mode
      `;
    }

    // Send message to background script
    chrome.tabs.query({ active: true, currentWindow: true }, function (tabs) {
      const tabId = tabs[0].id;

      // Check if content.js is already injected
      chrome.scripting.executeScript(
        {
          target: { tabId: tabId },
          files: ["content.js"],
        },
        () => {
          if (chrome.runtime.lastError) {
            console.error(
              "Failed to inject content script:",
              chrome.runtime.lastError.message
            );
          } else {
            console.log("Content script injected successfully");
            // Send a message to activate locator mode
            chrome.tabs.sendMessage(tabId, {
              action: "activateLocatorMode",
              isActive: true,
            });
          }
        }
      );
    });

    chrome.tabs.query({ active: true, currentWindow: true }, function (tabs) {
      chrome.tabs.sendMessage(
        tabs[0].id,
        { action: "activateLocatorMode" },
        function (response) {
          if (chrome.runtime.lastError) {
            console.error(
              "Error activating locator mode:",
              chrome.runtime.lastError.message
            );
          } else {
            console.log("Locator mode activated");
          }
        }
      );

      chrome.tabs.query({ active: true, currentWindow: true }, function (tabs) {
        chrome.tabs.sendMessage(
          tabs[0].id,
          { action: "ping" },
          function (response) {
            if (chrome.runtime.lastError) {
              console.error(
                "Content script not available:",
                chrome.runtime.lastError.message
              );
              alert(
                "Please open the DevTools panel or reload the page to activate the extension."
              );
            } else {
              console.log("Content script is available");
            }
          }
        );
      });
    });
  });

  // Toggle theme
  themeToggleBtn.addEventListener("click", function () {
    if (document.body.classList.contains("light-mode")) {
      document.body.classList.remove("light-mode");
      document.body.classList.add("dark-mode");
      localStorage.setItem("theme", "dark");
    } else {
      document.body.classList.remove("dark-mode");
      document.body.classList.add("light-mode");
      localStorage.setItem("theme", "light");
    }
  });

  // Listen for messages from content script
  chrome.runtime.onMessage.addListener(function (
    request,
    sender,
    sendResponse
  ) {
    if (request.action === "getLocators") {
      if (window.FeedbackService) {
        FeedbackService.incrementLocatorCount();
      }
      displayLocators(request.locators);
    }

    if (request.action === "locatorModeDeactivated") {
      isLocatorModeActive = false;
      locatorModeBtn.classList.remove("active-mode");
      locatorModeBtn.innerHTML = `
        <svg class="icon" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
          <path d="M3 3l7.07 16.97 2.51-7.39 7.39-2.51L3 3z"></path>
        </svg>
        Locator Mode
      `;
    }
  });

  // Display locators in the popup
  function displayLocators(locators) {
    // Reset validation states
    resetValidationVerdicts();
    document.querySelectorAll('.validate-btn').forEach(btn => {
      btn.classList.remove('validation-success', 'validation-failed', 'validating');
      btn.innerHTML = `
        <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
          <path d="M21 2l-2 2m-7.61 7.61a5.5 5.5 0 1 1-7.778 7.778 5.5 5.5 0 0 1-7.777-7.777zm0 0L15.5 7.5m0 0l3 3L22 7l-3-3m-3.5 3.5L19 4"></path>
        </svg>
        Validate
      `;
    });

    if (!locators || Object.keys(locators).length === 0) {
      locatorResults.innerHTML =
        '<p class="placeholder">No locators found for this element</p>';
      return;
    }

    let html = "";
    html += '<div class="locators-table">';

    // The engine hands back every locator it could build for the element,
    // ordered best-first. Older payloads (v1 engine) only have the flat
    // fields, so those still render from the explicit list below.
    const generated =
      Array.isArray(locators.locators) && locators.locators.length
        ? locators.locators
        : null;

    if (generated) {
      for (const loc of generated) {
        const label = [
          loc.type,
          loc.via ? `· ${loc.via}` : "",
          !loc.unique && !loc.approx ? `(${loc.matches} matches)` : "",
        ]
          .filter(Boolean)
          .join(" ");
        html += createLocatorItem(label, loc.value, loc);
      }
    } else {
      // Display high priority locators first
      if (locators.id) {
        html += createLocatorItem("ID", locators.id);
      }

      if (locators.dataTestId) {
        html += createLocatorItem("Data Test ID", locators.dataTestId);
      }

      if (locators.cssSelector) {
        html += createLocatorItem("CSS Selector", locators.cssSelector);
      }

      if (locators.cssByAttrPair) {
        html += createLocatorItem("CSS by Attr Pair", locators.cssByAttrPair);
      }

      // Display all XPath related locators
      if (locators.relativeXPath) {
        html += createLocatorItem("Relative XPath", locators.relativeXPath);
      }

      if (locators.xpathById) {
        html += createLocatorItem("XPath by ID", locators.xpathById);
      }

      if (locators.xpathByName) {
        html += createLocatorItem("XPath by Name", locators.xpathByName);
      }

      if (locators.xpathByDataTestId) {
        html += createLocatorItem("XPath by Data Test ID", locators.xpathByDataTestId);
      }

      if (locators.xpathByAriaLabel) {
        html += createLocatorItem("XPath by Aria Label", locators.xpathByAriaLabel);
      }

      if (locators.xpathByPlaceholder) {
        html += createLocatorItem("XPath by Placeholder", locators.xpathByPlaceholder);
      }

      if (locators.xpathByText) {
        html += createLocatorItem("XPath by Text", locators.xpathByText);
      }

      if (locators.partialTextXPath) {
        html += createLocatorItem(
          "XPath by Partial Text",
          locators.partialTextXPath
        );
      }

      // Display All XPaths section with validation
      if (locators.allXPaths && locators.allXPaths.length > 0) {
        html += `<div class="locator-item"><span class="locator-type">All XPaths:</span></div>`;
        locators.allXPaths.forEach((xpath) => {
          html += `
            <div class="locator-item">
              <span class="locator-value">${xpath}</span>
              <div class="locator-actions">
                <button class="validate-btn" data-type="XPath" data-value="${escapeHtml(
                  xpath
                )}" title="Validate locator">
                  <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                    <path d="M21 2l-2 2m-7.61 7.61a5.5 5.5 0 1 1-7.778 7.778 5.5 5.5 0 0 1-7.777-7.777zm0 0L15.5 7.5m0 0l3 3L22 7l-3-3m-3.5 3.5L19 4"></path>
                  </svg>
                  Validate
                </button>
                <button class="copy-btn" data-value="${escapeHtml(xpath)}">
                  <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                    <rect x="9" y="9" width="13" height="13" rx="2" ry="2"></rect>
                    <path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1-2-2h9a2 2 0 0 1 2 2v1"></path>
                  </svg>
                  Copy
                </button>
              </div>
            </div>
          `;
        });
      }

      // Display lower priority locators at the bottom
      if (locators.className) {
        html += createLocatorItem("Class Name", locators.className);
      }

      if (locators.tagName) {
        html += createLocatorItem("Tag Name", locators.tagName);
      }

      if (locators.linkText) {
        html += createLocatorItem("Link Text", locators.linkText);
      }

      if (locators.partialLinkText) {
        html += createLocatorItem("Partial Link Text", locators.partialLinkText);
      }
    }

    html += "</div>";
    locatorResults.innerHTML = html;

    // Add event listeners to copy and validate buttons
    document.querySelectorAll(".copy-btn").forEach((btn) => {
      btn.addEventListener("click", function () {
        const value = this.getAttribute("data-value");
        copyToClipboard(value, this);
      });
    });

    addValidationListeners();
    // Auto-validation lives in the DevTools panel, which has the toggle for
    // it. The popup used to call an autoValidateLocators() that was never
    // defined here, throwing a ReferenceError on every render.
  }

  // Helper function to create locator item. `loc` is the engine's entry for
  // this locator when we have one — it carries the strategy and a CSS/XPath
  // equivalent so the page can resolve it exactly.
  function createLocatorItem(type, value, loc) {
    const meta = loc
      ? ` data-strategy="${escapeHtml(loc.strategy || "")}"` +
        ` data-verify-kind="${escapeHtml(loc.verifyKind || "")}"` +
        ` data-verify-expr="${escapeHtml(loc.verifyExpr || "")}"`
      : "";
    return `
      <div class="locator-item">
        <span class="locator-type">${escapeHtml(type)}:</span>
        <span class="locator-value">${escapeHtml(value)}</span>
        <div class="locator-actions">
          <button class="validate-btn" data-type="${escapeHtml(type)}" data-value="${escapeHtml(value)}"${meta}>
            <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
              <path d="M20 6L9 17l-5-5"/>
            </svg>
            Validate
          </button>
          <button class="copy-btn" data-value="${escapeHtml(value)}">
            <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
              <rect x="9" y="9" width="13" height="13" rx="2" ry="2"></rect>
              <path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1-2-2h9a2 2 0 0 1-2 2v1"></path>
            </svg>
            Copy
          </button>
        </div>
      </div>
    `;
  }

  // Add event listener for validate buttons
  function addValidationListeners() {
    document.querySelectorAll(".validate-btn").forEach((btn) => {
      btn.addEventListener("click", function () {
        const type = this.getAttribute("data-type");
        const value = this.getAttribute("data-value");
        const strategy = this.getAttribute("data-strategy");
        const verifyKind = this.getAttribute("data-verify-kind");
        const verifyExpr = this.getAttribute("data-verify-expr");

        beginValidationRound(type, value);

        // Send validation request to content script
        chrome.tabs.query(
          { active: true, currentWindow: true },
          function (tabs) {
            chrome.tabs.sendMessage(tabs[0].id, {
              action: "validateLocator",
              locatorType: type,
              locatorValue: value,
              locatorStrategy: strategy || null,
              locatorVerifyKind: verifyKind || null,
              locatorVerifyExpr: verifyExpr || null,
            });
          }
        );

        // Add visual feedback
        this.classList.add("validating");
        setTimeout(() => {
          this.classList.remove("validating");
        }, 2000);
      });
    });
  }

  // Validation verdicts.
  //
  // The content script runs in every frame of the tab — including about:blank
  // ones — and `chrome.tabs.sendMessage` with no frameId broadcasts to all of
  // them, so one click yields one reply per frame: "found" from the frame
  // holding the element, "not found" from every other. Painting whichever
  // reply lands last marks a working locator as Failed, so a success from any
  // frame wins: it paints immediately, while a failure waits briefly and is
  // dropped if a success shows up.
  const VALIDATION_FAILURE_GRACE_MS = 400;
  const validationVerdicts = new Map();

  function resetValidationVerdicts() {
    for (const state of validationVerdicts.values()) {
      if (state.timer) clearTimeout(state.timer);
    }
    validationVerdicts.clear();
  }

  // Each click starts a fresh round, so the previous verdict for that locator
  // must not linger — otherwise a locator that was Valid keeps reading Valid
  // after the page changed under it.
  function beginValidationRound(type, value) {
    const key = `${type} ${value}`;
    const state = validationVerdicts.get(key);
    if (state && state.timer) clearTimeout(state.timer);
    validationVerdicts.delete(key);
  }

  function paintValidationVerdict(type, value, ok) {
    document.querySelectorAll(".validate-btn").forEach((btn) => {
      if (btn.dataset.type !== type || btn.dataset.value !== value) return;
      btn.classList.remove("validating");
      btn.classList.toggle("validation-success", ok);
      btn.classList.toggle("validation-failed", !ok);
      btn.innerHTML = ok
        ? `
              <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                <path d="M20 6L9 17l-5-5"/>
              </svg>
              Valid
            `
        : `
              <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                <circle cx="12" cy="12" r="10"/>
                <line x1="15" y1="9" x2="9" y2="15"/>
                <line x1="9" y1="9" x2="15" y2="15"/>
              </svg>
              Failed
            `;

      // Back to "Validate" after 3 seconds, unless a new run is in flight.
      setTimeout(() => {
        if (btn.classList.contains("validating")) return;
        btn.classList.remove("validation-success", "validation-failed");
        btn.innerHTML = `
                <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                  <path d="M20 6L9 17l-5-5"/>
                </svg>
                Validate
              `;
      }, 3000);
    });
  }

  // Add listener for validation results
  chrome.runtime.onMessage.addListener(function (message) {
    if (message.action !== "validationResult") return;

    const key = `${message.locatorType} ${message.locatorValue}`;
    const state = validationVerdicts.get(key) || { succeeded: false, timer: null };

    if (message.success) {
      if (state.timer) clearTimeout(state.timer);
      validationVerdicts.set(key, { succeeded: true, timer: null });
      paintValidationVerdict(message.locatorType, message.locatorValue, true);
      return;
    }

    if (state.succeeded || state.timer) return;
    state.timer = setTimeout(() => {
      const latest = validationVerdicts.get(key);
      if (latest && latest.succeeded) return;
      paintValidationVerdict(message.locatorType, message.locatorValue, false);
    }, VALIDATION_FAILURE_GRACE_MS);
    validationVerdicts.set(key, state);
  });

  // Helper function to copy to clipboard
  function copyToClipboard(text, buttonElement) {
    // Create a temporary textarea element
    const textarea = document.createElement("textarea");
    textarea.value = text;
    textarea.setAttribute("readonly", "");
    textarea.style.position = "absolute";
    textarea.style.left = "-9999px";
    document.body.appendChild(textarea);

    // Select the text and copy
    textarea.select();
    document.execCommand("copy");

    // Remove the textarea
    document.body.removeChild(textarea);

    // Change button text temporarily
    const originalHTML = buttonElement.innerHTML;
    buttonElement.innerHTML = `
      <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
        <polyline points="20 6 9 17 4 12"></polyline>
      </svg>
      Copied!
    `;

    // Show global notification
    copyNotification.classList.add("show");

    // Reset after 2 seconds
    setTimeout(() => {
      buttonElement.innerHTML = originalHTML;
      copyNotification.classList.remove("show");
    }, 2000);
  }

  // Helper function to escape HTML
  function escapeHtml(unsafe) {
    return unsafe
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;")
      .replace(/'/g, "&#039;");
  }

  // Load saved locators
  function loadSavedLocators() {
    chrome.storage.local.get(["savedLocators"], function (result) {
      if (result.savedLocators && result.savedLocators.length > 0) {
        let html = "";
        result.savedLocators.forEach((item, index) => {
          html += `
            <div class="locator-item">
              <div><strong>${new Date(
                item.timestamp
              ).toLocaleString()}</strong></div>
              <div>${item.url}</div>
              <div class="locator-value">${
                item.locators.cssSelector || item.locators.xpath
              }</div>
              <button class="copy-btn" data-value="${escapeHtml(
                item.locators.cssSelector || item.locators.xpath
              )}">
                <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                  <rect x="9" y="9" width="13" height="13" rx="2" ry="2"></rect>
                  <path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1-2-2h9a2 2 0 0 1-2 2v1"></path>
                </svg>
                Copy
              </button>
            </div>
          `;
        });
        savedLocators.innerHTML = html;

        // Add event listeners to copy buttons
        document.querySelectorAll("#savedLocators .copy-btn").forEach((btn) => {
          btn.addEventListener("click", function () {
            const value = this.getAttribute("data-value");
            copyToClipboard(value, this);
          });
        });
      } else {
        savedLocators.innerHTML =
          '<p class="placeholder">No saved locators yet</p>';
      }
    });
  }

  // Initial load of saved locators
  // loadSavedLocators();

  // Check for updates
  checkVersionUpdate();

  async function checkVersionUpdate() {
    try {
      const response = await fetch(`${WORKER_BASE}/api/latest-version?source=locator-spy`);
      const data = await response.json();
      const latestVersion = data.version;
      const currentVersion = chrome.runtime.getManifest().version;

      if (isNewerVersion(latestVersion, currentVersion)) {
        showUpdateAlert(latestVersion);
      }
    } catch (error) {
      console.error('Error checking for updates:', error);
    }
  }

  function isNewerVersion(latest, current) {
    const latestParts = latest.split('.').map(Number);
    const currentParts = current.split('.').map(Number);
    
    for (let i = 0; i < Math.max(latestParts.length, currentParts.length); i++) {
      const v1 = latestParts[i] || 0;
      const v2 = currentParts[i] || 0;
      if (v1 > v2) return true;
      if (v1 < v2) return false;
    }
    return false;
  }

  function showUpdateAlert(version) {
    const updateAlert = document.getElementById('updateAlert');
    if (!updateAlert) return;
    
    const versionSpan = updateAlert.querySelector('span');
    versionSpan.textContent = `Update available! v${version} is now live.`;
    updateAlert.classList.remove('hidden');
    
    document.getElementById('updateNowBtn').addEventListener('click', () => {
      chrome.tabs.create({ url: 'https://chromewebstore.google.com/detail/locator-finder-ai-powered/gpgjidcedjiphbgagldchpcliacmanjf' });
    });

    document.getElementById('closeUpdateAlert').addEventListener('click', () => {
      updateAlert.classList.add('hidden');
    });
  }
});

// Dropdown menu functionality
document.addEventListener("DOMContentLoaded", () => {
  const menuBtn = document.getElementById("menuBtn");
  const dropdownMenu = document.getElementById("dropdownMenu");

  menuBtn.addEventListener("click", (e) => {
    e.stopPropagation();
    dropdownMenu.classList.toggle("show");
    menuBtn.setAttribute(
      "aria-expanded",
      dropdownMenu.classList.contains("show")
    );
  });

  // Close dropdown when clicking outside
  document.addEventListener("click", (e) => {
    if (!menuBtn.contains(e.target)) {
      dropdownMenu.classList.remove("show");
      menuBtn.setAttribute("aria-expanded", "false");
    }
  });

  // Prevent dropdown from closing when clicking inside
  dropdownMenu.addEventListener("click", (e) => {
    e.stopPropagation();
  });
});
