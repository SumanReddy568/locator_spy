document.addEventListener('DOMContentLoaded', () => {
    initSignup();
});
