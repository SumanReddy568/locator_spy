## [1.0.9] - 2025-04-03
- pop up changes sed change

## [1.0.8] - 2025-04-03
- pop up changes sed change

## [1.0.8] - 2025-04-03
- pop up changes

## [1.0.8] - 2025-04-03
- pop up changes

## [1.0.8] - 2025-04-03
- version bump

## [1.0.9] - 2025-04-03
- service worker fix

## [1.0.7] - 2025-03-30
- Merge pull request #7 from SumanReddy568/enhace_ziper Enhace ziper

## [1.0.8] - 2025-03-30
- Merge pull request #6 from SumanReddy568/enhace_ziper zipeer change

## [1.0.7] - 2025-03-29
- pannel headder update

## [1.0.6] - 2025-03-29
- Merge pull request #5 from SumanReddy568/loc_acc_imp improved xpath accuracy

## [1.0.5] - 2025-03-29
- Merge pull request #4 from SumanReddy568/dev2 acuracy improve

## [1.0.4] - 2025-03-29
- Merge pull request #2 from SumanReddy568/develop1 added change log file mainatence and fixed version update in pannel.html

# Changelog

All notable changes to this project will be documented in this file.

